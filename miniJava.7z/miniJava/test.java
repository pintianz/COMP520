// PA1 lex unop pass
class id {
	int zz;
    void p(){
    	//boolean zz=true;
    	//boolean b = true;
    	IDid ii = new IDid();
        //boolean x =  IDid.zz;
    	//boolean x =  ii.zz;
    	boolean x =  IDid.zz;
    	int a = zz+1;
    	System.out.println(x);
    	if(true)int x = 1;
    }
}
class IDid {
	static boolean zz;
}

class id2 {
	//boolean b = true;
	static boolean x;
}
