// PA1 parse local decl fail
class id {
    public void f(){
        Ref [] x(33);
    }
}


