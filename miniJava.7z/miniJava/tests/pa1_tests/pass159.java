// PA1 parse refs pass
class Test {

    int [] a;
    Test [] t;

    int p() {
        this[e] = this + 1;
    }
}

