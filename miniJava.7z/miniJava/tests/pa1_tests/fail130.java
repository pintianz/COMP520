// PA1 lex trailing start char fail
class Almost {
   public static void main (String [] args) {
   } // nothing follows next slash
} /