// PA1 lex id fail
class boolean {}
