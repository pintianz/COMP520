// PA1 parse field decl pass
class id {
    static Type x;
}

