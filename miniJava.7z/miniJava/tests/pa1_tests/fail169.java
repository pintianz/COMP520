// PA1 parse new fail
class Test {

    void p() {
	x = new Foo(10);
    }
}

