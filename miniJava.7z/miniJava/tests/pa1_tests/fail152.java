// PA1 parse expr fail
class NonTokens{
   int main () {
      return a++b;
   }
}
