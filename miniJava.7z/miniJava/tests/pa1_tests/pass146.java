// PA1 parse field decl pass
class id {
    void x;
}

