// PA1 parse field decl pass
class id {
    public static Type x;
}

