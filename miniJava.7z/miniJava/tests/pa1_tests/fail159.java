// PA1 parse method fail
class IllegalExpressions {
    void foo () {
        if (x != 0)
	    return x;
        return y; 
   }
}
