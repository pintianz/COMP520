// PA1 parse local decl fail
class LValueFail {
   void foo () {
      true = false;
   }
}
