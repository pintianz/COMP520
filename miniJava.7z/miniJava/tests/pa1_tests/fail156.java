// PA1 parse expr fail
class IllegalExpressions {
   static void foo (int a) {
      if (a = a) {
         a = a;
      }
   }
}
