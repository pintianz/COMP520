// PA1 lex comment fail
class /* /* nested */ */ id {}

