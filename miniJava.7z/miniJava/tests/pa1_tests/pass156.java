// PA1 lex binop pass
class id {
    void p(){
        int x = 1 + 2 * 3 / 4 > 5 >= 6 < 7 <= 8 != 9 && 0 || 1;
    }
}

