// PA1 lex/parse binop fail
class id {
    void p(){
        int x = 1 >> 0;
    }
}

