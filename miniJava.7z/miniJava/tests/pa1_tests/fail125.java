// PA1 lex binop fail
class id {
    void p(){
        int x = 1 &| 0;
    }
}

