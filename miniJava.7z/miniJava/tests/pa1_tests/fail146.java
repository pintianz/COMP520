// PA1 parse local decl fail
class id {
    void foo() {
        Nonesuch x[2] = 3;
    }
}


