// PA1 lex unop pass
class id {
    void p(){
        int y = --y;
    }
}

