// PA1 parse ref fail
class Test {

    int p() {
	a[3](x);
    }
}

