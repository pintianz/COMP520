// PA1 parse refs fail
class Test {

    int p() {
        a[3].b = 42;
    }
}

