// PA1 parse method decl pass
class id {
    private int f(int x, boolean b) {return 3;}
}

