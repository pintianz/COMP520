// PA1 Parse Type fail
class id {
    int foo() {
	void x = 3;
    }
}
