// PA1 parse ref fail
class Test {

    int p() {
	Test x = 1 + a[3](y);
    }
}

