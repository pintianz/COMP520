// PA1 lex unop pass
class id {
    void p(){
        boolean x =  !!!!!b;
    }
}

