// PA1 parse assign fail
class Test {

    void p(int a) {
        Test [ ]  = a * 3;
    }
}

