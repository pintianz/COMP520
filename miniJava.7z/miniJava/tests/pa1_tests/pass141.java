// PA1 parse field decl pass
class id {
    private static Type x;
}

