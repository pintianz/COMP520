// PA1 parse local decl fail
class idfail {
   public void foo () {
      int [] x[3] = null;
   }
}
