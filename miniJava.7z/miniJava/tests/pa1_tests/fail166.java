// PA1 parse ref fail
class Test {

    void p(int a) {
	that.this = 4;
    }
}

