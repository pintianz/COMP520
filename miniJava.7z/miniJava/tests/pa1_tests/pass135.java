// PA1 lex comment pass
class id {} // trailing comment terminated by \n 
