// PA1 lex binop fail
class id {
    void p(){
        while ( 1 > = 0) {}
    }
}

