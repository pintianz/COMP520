// PA1 lex comment pass
class // comment followed by \n only 
id {}
