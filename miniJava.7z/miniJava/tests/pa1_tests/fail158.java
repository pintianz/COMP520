// PA1 parse ref fail
class IllegalExpressions {
    void foo () {
      a [b] [c] = d;   // not ok
   }
}
