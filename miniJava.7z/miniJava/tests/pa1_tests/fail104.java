// PA1 lex id fail
class true {}
