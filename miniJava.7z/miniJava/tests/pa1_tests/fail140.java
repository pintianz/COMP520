// PA1 parse field decl fail
class id {
    static private Type x;
}


