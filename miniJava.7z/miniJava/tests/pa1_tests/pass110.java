// PA1 lex comment pass
class // comment $$ followed by \r\n
id {}
