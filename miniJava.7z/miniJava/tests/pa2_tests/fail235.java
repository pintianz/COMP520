//PA2 fail qualified reference expression
class A {
    private void p(){
        int a = x[3].y[4];
    }
}
