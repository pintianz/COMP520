// PA2 pass parameter decl
class A {
    void p(int [] m){}
}
