// PA2 stmt fail
class A {
    void p(){
        if x  
            int x = 3;
    }
}
