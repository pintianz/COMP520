// PA2 illegal array type
class A {
    int p(void [] x){}
}
