// PA2 expr fail
class A {
    void p(){
	int b = c / * d /* */;    
    }
}
