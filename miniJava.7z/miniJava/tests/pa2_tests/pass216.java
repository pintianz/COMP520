// PA2 pass unary expr
class A {
    void f(){
        boolean p = p && !!p;
    }
}
