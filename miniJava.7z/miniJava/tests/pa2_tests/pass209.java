//PA2 pass qualified reference assignment
class A {
    void p(){
        x.y[3] = 3;
    }
}
