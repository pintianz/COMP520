// PA2 stmt fail
class A {
    void p(){
        this;
    }
}
