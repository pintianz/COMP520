// PA2 pass this RefExpr
class A {
    A p(){
        return this;
    }
}
