// PA2 pass local decl
class A {
    int p(){
        Foo x = 3;
    }
}
