// PA2 missing first parameter name
class A {
    int p(A [], int b){}
}
