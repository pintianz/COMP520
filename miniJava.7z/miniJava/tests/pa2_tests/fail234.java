// PA2 invalid type in parameter declaration
class A {
    void p(void [] x){ }
}
