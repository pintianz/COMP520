package miniJava.ContextualAnalyzer;

public enum RefContext {StaticClass, InstanceClass, ThisClass}