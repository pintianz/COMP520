/**
 * miniJava Abstract Syntax Tree classes
 * @author prins
 * @version COMP 520 (v2.2)
 */
package miniJava.AbstractSyntaxTrees;

import miniJava.SyntacticAnalyzer.SourcePosition;

public class QualifiedRef extends Reference {
	
	public QualifiedRef(Reference ref, Identifier id, SourcePosition posn){
		super(posn);
		this.ref = ref;
		this.id  = id;
	}

	@Override
	public <A, R> R visit(Visitor<A, R> v, A o) {
		return v.visitQualifiedRef(this, o);
	}

	public Reference ref;
	public Identifier id;
	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return id.spelling;
	}
}
