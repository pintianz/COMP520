//  PA2 pass expr precedence
class A { 
    int f ( ) { 
        boolean x = false && 2 >= 3 || true; 
    } 
}
