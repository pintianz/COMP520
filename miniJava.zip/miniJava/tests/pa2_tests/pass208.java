// PA2 pass qualified ref invocation
class A {
    void p(){
        x.y(3);
    }
}
