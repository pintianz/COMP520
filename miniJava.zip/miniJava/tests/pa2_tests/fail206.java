// PA2 statement after return
class A {
    int p(){
        return 2; 
        x = 3;
    }
}
