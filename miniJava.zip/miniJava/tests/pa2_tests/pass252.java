//  PA2 pass expr precedence
class A { 
    int f() { 
        x = 1 * 2 / 3; 
    } 
}
