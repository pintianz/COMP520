// PA2 unop pass
class id {
    void p(){
        int x =  b - - - -b;
    }
}

