// PA2 pass indexed ref
class A {
    void p(){
        A x = this.x[3];
    }
}
