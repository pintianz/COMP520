// PA1 parse Stmt this ref pass
class LegalStmt {
   void main () {
       this(3,4);
   }
}
