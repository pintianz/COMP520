// PA2 pass stmt
class A {
    A p(){
        while (true) {}
    }
}
