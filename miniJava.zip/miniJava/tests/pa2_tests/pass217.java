// PA2 pass stmt
class A {
    void f(int a, int b){
        if (a < b) b = a;
    }
}
