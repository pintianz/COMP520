// PA2 local var decl fail
class A {

    A p(){
        private int stuff = 3;
    }
}
