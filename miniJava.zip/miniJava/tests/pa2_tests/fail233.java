// PA2 incorrect new expr
class A {
    void p(){  x = new void [3]; }
}
