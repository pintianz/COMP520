// PA2 incorrect reference
class A {
    void p(){  x = a.this; }
}
