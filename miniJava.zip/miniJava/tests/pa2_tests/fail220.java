// PA2 stmt fail
class A {
    private void p(){
        return;
    }
}
