// PA2 pass expr
class A {
    private int f(){
        return a[3]() + 1;
    }
}
