// PA2 lex fail
class A {
    void f(){
        p = p & !p;
    }
}
