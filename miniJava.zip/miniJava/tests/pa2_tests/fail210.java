// PA2 parameter decl fail
class A {
    void foo(x){}
}
