// PA2 pass method decl
class A {
    private void p(){
        return 0;
    }
}
