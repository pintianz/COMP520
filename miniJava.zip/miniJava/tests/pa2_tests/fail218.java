// PA2 predecrement fail
class A {
    void f(){
        c = --b;
    }
}
