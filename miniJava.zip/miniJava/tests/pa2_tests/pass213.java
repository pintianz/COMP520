// PA2 pass thisref
class A {
    void p(){
        A x = this;
    }
}
