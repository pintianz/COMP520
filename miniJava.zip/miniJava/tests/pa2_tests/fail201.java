// PA2 local var decl fail
class A {
    int p(){A A A = b;}
}
