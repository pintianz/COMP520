// PA2 pass stmt
class A {
    private void f(){
        a[3]();
    }
}
