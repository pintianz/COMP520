// PA2 expr fail
class A {
    void f(){
        c = a <=< b;
    }
}
