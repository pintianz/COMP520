// PA2 pass indexedRef
class A {
    void p(){
        A x = x.y[3];
    }
}
