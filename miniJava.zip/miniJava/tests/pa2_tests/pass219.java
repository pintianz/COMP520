// PA2 binop pass
class id {
    void p(){
        boolean x = true && false || x;
    }
}

