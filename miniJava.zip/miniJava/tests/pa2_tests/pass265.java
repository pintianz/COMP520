//  PA2 pass expr precedence
class A {
    int f (){
        int d = 2+-x- -x;
    }
}
