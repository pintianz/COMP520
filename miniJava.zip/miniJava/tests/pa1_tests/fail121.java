// PA1 Parse Type fail
class id {
    int foo(void y) {
	y = y + 1;
    }
}
