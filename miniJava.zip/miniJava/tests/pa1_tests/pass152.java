// PA1 parse new pass
class MainClass {
   public static void main (String [] args) {
      SecondSubClass newobj = new SecondSubClass ();
   }
}


