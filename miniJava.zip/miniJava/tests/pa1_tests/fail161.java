// PA1 parse decl fail
class Test {

    void p() {
        boolean [] a = b;
    }
}

