// PA1 parse assign pass
class Test {

    void p() {
	x.y = z;
    }
}

