// PA1 lex comment pass
class /* comment */ id {}

