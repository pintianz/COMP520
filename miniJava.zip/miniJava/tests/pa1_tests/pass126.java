// PA1 lex binop pass
class id {
    void p(){
        boolean x = true && false || x;
    }
}

