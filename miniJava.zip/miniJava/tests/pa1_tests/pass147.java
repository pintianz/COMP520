// PA1 parse method decl pass
class id {
    public static void main(String[] args){}
}

