// PA1 lex comment fail
class id {} /* unterminated 
