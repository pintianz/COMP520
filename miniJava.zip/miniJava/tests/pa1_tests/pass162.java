// PA1 parse ref pass
class Test {

    void p(int a, boolean b) {
        this.p(a,b);
    }
}

