// PA1 parse field decl fail
class id {
    void int x;
}


