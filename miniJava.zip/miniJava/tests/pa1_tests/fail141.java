// PA1 parse field decl fail
class id {
    public private static Type x;
}


