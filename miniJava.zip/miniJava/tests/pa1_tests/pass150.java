// PA1 parse classdecls pass
class MainClass {
    public static void main (String [] args) {}
}

class OfItsOwn {
   int A_01;
}  // class OfItsOwn

