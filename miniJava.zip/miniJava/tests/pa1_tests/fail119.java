// PA1 lex ill char fail
class NonTokens{} #
