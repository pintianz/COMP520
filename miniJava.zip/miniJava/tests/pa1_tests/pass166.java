// PA1 parse assign pass
class Test {

    void p(int a) {
	this.p(2,3);
	a.v[3] = 4;
    }
}

