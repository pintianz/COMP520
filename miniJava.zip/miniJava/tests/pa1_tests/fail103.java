// PA1 parse fail
class Foo {}.