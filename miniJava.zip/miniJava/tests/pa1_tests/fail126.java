// PA1 lex binop fail
class id {
    void p(){
        x = 1 + 2*3 = 4;
    }
}

