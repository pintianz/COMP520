// PA1 parse assign pass
class Test {

    void p() {
        a = b;
    }
}

