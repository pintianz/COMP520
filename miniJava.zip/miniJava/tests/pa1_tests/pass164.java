// PA1 parse assign pass
class Test {

    void p(int a) {
        Test [ a + 1]  = a * 3;
    }
}

