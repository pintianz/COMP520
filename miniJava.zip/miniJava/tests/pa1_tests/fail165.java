// PA1 parse index fail
class Test {

    int p(int a) {
	x = c.p(2,3)[3];
    }
}

