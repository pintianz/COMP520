// PA1 lex id pass
class Class{}

