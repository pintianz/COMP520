// PA1 parse methods pass
class MainClass {
   public static void main (String [] args) {
   }
}
class SuperClass
{
   public void setWorth (int worth){
      integer = worth;
   }
   
   public int getWorth (){
      return this.integer;
   }
   
   public void setTruth (boolean truth){
      bool = truth;
   }
   
   public int getTruth (){
      return this.bool;
   }
}
