// PA1 parse ref fail
class Test {

    int p() {
	int d = 2 + a.b[i](x,y);
    }
}

