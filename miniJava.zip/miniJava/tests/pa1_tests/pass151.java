// PA1 parse identifiers pass
class Keywords {

    // minijava keywords are lower case only
    void p() {
        int format = while_1;
        int Int = New;
        For = Class;     
        FOR = RETURN;
    }

   public int declare () {
      boolean iF = true; 
      boolean Then = false; 
      boolean else1 = false;

      if (true == false) { else1 = iF == Then; }
   }
} 

