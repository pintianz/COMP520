// PA1 lex comment pass
class id {} // unterminated comment - no trailing \r\n    