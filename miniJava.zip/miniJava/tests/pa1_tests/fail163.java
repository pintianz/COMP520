// PA1 parse ref fail
class Test {

    void p(int a) {
        Test [ ]  x = a.b[3](x);
    }
}

