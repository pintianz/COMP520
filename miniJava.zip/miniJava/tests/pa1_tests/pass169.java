// PA1 parse new pass
class Test {

    void p() {
	Foo [] foo = new Foo [10];
    }
}

