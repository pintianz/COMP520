// PA1 parse new pass
class Foo {
   void bar() {
      int[] newarr = new int[20];
   }
}


