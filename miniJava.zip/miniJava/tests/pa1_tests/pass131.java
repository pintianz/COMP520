// PA1 lex whitespace including tab
class Test {
 		 /* multiple comments between
     */    

    // tokens

    /**//* is OK */


}

